#include "hello.h"
#include <iostream>

void helloWorld() {
    std::cout << "Hello, world!" << std::endl;
}