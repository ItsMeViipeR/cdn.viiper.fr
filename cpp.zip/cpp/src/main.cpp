#include "hello.h"

int main() {
    helloWorld();
    return 0;
}